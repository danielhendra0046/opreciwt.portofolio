<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="alert alert-danger" role="alert">
        Sorry, You have been blocked!
        (Harap lengkapi persyaratan dengan benar).
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->