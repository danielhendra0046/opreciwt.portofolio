<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>



    <div class="row">
        <div class="col-lg-6">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">User</th>
                        <th scope="col">Action</th>
                        <th scope="col">Role</th>
                        <th scope="col">Role Changer</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($peserta as $p) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $p['name']; ?></td>
                            <td>
                                <a href="<?= base_url('admin/detail/') . $p['id']; ?>" class="badge badge-success">Detail Peserta</a>
                            </td>
                            <td>
                                <input type="text" class="form-control" id="role" name="role" value="<?= $p['role_id']; ?>" readonly>
                            </td>
                            <td>
                                <a href="<?= base_url('admin/rolechanger/') . $p['id']; ?>" class="badge badge-danger">Ubah Role</a>
                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>


        </div>
    </div>




</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->