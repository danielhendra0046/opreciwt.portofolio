<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="form-group row">
        <div class="row-12">
            <div class="col-sm-12">
                <img src="<?= base_url('assets/img/profile/0001.jpg'); ?>" class="img-thumbnail">
            </div>
        </div>
    </div>
</div>
</div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->